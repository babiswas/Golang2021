package User

type User struct{
  FirstName string `json:"first-name"`
  LastName string  `json:"last-name"`
  Email string     `json:"email"`
}

func (u *User)SetFirstName(fname string){
   u.FirstName=fname
}

func (u *User)SetLastName(lname string){
   u.LastName=lname
}

func (u *User)SetEmail(email string){
   u.Email=email
}

func CreateUser(fname,lname,email string)(*User){
    user:=User{}
    user.SetFirstName(fname)
    user.SetLastName(lname)
    user.SetEmail(email)
    return &user
}

