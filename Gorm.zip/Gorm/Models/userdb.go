package Models

import (
	"Gorm/Models/User"
	"fmt"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func Get_db() (*gorm.DB, error) {
	dsn := "host=localhost user=postgres password=36network dbname=muser port=5433"
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		fmt.Println("Error Occured")
		return db, err
	}
	return db, nil
}

func Create_Table() {
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured")
		return
	}
	if !db.Migrator().HasTable("users") {
		db.AutoMigrate(&User.User{})
	} else {
		fmt.Println("Table exists")
	}
}

func Create_User(fname, lname, email string) error {
	user := User.User{}
	user.SetFirstName(fname)
	user.SetLastName(lname)
	user.SetEmail(email)
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err)
		return err
	}
	db.Create(&user)
	if err != nil {
		fmt.Println("Error occured", err)
		return err
	}
	return nil
}

func Get_First_User() User.User {
	var user User.User
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err)
	}
	db.First(&user)
	return user
}

func Get_Any_User() User.User {
	var user User.User
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err)
	}
	db.Take(&user)
	return user
}

func Get_Last_User() User.User {
	var user User.User
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err)
	}
	db.Last(&user)
	return user
}

func Get_All_User() []User.User {
	var users []User.User
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err)
	}
	db.Find(&users)
	return users
}

func Get_Ur_User(name string) {
	type Myuser struct {
		Name  string
		Email string
	}
	var m Myuser
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured", err)
	}
	db.Raw("SELECT first_name,email FROM users WHERE first_name=?", name).Scan(&m)
	fmt.Println(m)
}

func Get_users() {
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured", err)
		return
	}
	row, err := db.Model(&User.User{}).Rows()
	defer row.Close()
	for row.Next() {
		var user User.User
		db.ScanRows(row, &user)
		fmt.Println(user)
	}
}

func Get_all_users() {
	type APIUser struct {
		FirstName string
		Email     string
	}
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured", err)
	}
	row, err := db.Model(&User.User{}).Limit(10).Find(&APIUser{}).Rows()
	if err != nil {
		fmt.Println("Error Occured")
	}
	for row.Next() {
		var user APIUser
		db.ScanRows(row, &user)
		fmt.Println(user)
	}
}

func Get_All_Names() {
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured", err)
	}
	row, err := db.Model(&User.User{}).Select("FirstName").Rows()
	if err != nil {
		fmt.Println("Error occured")
	}
	for row.Next() {
		var name string
		db.ScanRows(row, &name)
		fmt.Println(name)
	}
}

func Update_User(name string) {
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err)
	}
	db.Model(&User.User{}).Where("first_name=?", name).Update("last_name", "Deb")
}
