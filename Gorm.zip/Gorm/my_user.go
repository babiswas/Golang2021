package main

import (
	"Gorm/Models"
	"fmt"
)

func main() {
	var fname string
	var lname string
	var email string
	fmt.Println("Enter the firstname of the user")
	fmt.Scanln(&fname)
	fmt.Println("Enter the secondname of the user")
	fmt.Scanln(&lname)
	fmt.Println("Enter the email of the user")
	fmt.Scanln(&email)
	err := Models.Create_User(fname, lname, email)
	if err != nil {
		fmt.Println("Error Occured", err)
	}
	fmt.Println(Models.Get_First_User())
	fmt.Println("Displaying the first user:")
	fmt.Println(Models.Get_Any_User())
	fmt.Println("Displaying the last user:")
	fmt.Println(Models.Get_Last_User())
	fmt.Println("Displaying all users")
	fmt.Println(Models.Get_All_User())
	fmt.Println("Displaying ur user")
	Models.Get_Ur_User("Bapan")
	fmt.Println("Displaying users")
	Models.Get_users()
	fmt.Println("Displaying all users:")
	Models.Get_all_users()
	fmt.Println("Get all the names")
	Models.Get_All_Names()
	var name string
	fmt.Println("Enter the name fro update:")
	fmt.Scanln(&name)
	Models.Update_User(name)
}
